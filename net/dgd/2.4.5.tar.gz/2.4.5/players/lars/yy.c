inherit "/obj/torch";

short() {
    return "En {rvd fakla";
}
