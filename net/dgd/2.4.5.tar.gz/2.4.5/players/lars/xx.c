func() {
    combine_free_list();
    write(pointerp(slice_array(({1}), 0, 0)));
}
