# define RESET_TIME	30
# define LOG_FILE_SIZE	50000
# define LOG_SHOUT
# define MAX_BITS	1200
# define FILE_CHUNK	5000
# define TAIL_CHUNK	1000
# define TAIL_LINES	20
# define CAT_LINES	40

# define AUTO		"/dgd/lib/auto"
# define DRIVER		"/dgd/sys/driver"
# define GLOBAL		"/dgd/sys/global"
# define HNAME		"/dgd/sys/hname"
# define USER		"/dgd/std/user"
# define PLAYER		"/dgd/lib/player"
# define MASTER		"/obj/master"
# define EDITOR		"/dgd/std/editor"
# define CINDENT	"/dgd/std/cindent"

# define LAMBDA		"L\340mb\360\341"
