# define status		int
# define public		/* nothing */
# define closure	mixed *
