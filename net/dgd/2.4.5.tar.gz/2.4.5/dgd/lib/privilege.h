# define PRIVILEGED()	(previous_object()->_Q_priv())

/* extern int privileged; */

# define INIT_PRIVILEGE()
