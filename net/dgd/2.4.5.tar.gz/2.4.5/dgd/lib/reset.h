# define INIT_RESET()	_F_reset0()
