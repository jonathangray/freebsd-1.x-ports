private int query_light(object obj);
private int add_light(int i);

static int set_light(int i);

# define INIT_LIGHT()
