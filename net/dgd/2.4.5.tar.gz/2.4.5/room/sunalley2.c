#include "room.h"
ONE_EXIT("room/sunalley1","east",
"Sun alley",
"Sun alley runs east from here.\n",
1)
