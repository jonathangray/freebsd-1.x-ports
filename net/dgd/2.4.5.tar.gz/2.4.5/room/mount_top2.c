#include "room.h"

ONE_EXIT("room/mount_top", "west",
	 "Plateau",
	 "You are on a large, open plateau on top of the mountain.\n"+
   "The view is fantastic in all directions and the clouds\n"+
   "that rush past above feels so close you could almost\n"+
   "touch them. The air here is fresh and clean.\n",1)

