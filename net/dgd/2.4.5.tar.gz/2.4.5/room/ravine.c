#include "room.h"

TWO_EXIT("room/mount_pass", "down",
	 "room/mount_top", "up",
	 "Ravine",
	 "You are in a ravine between mountains. It seems to be possible\n"+
	 "to go up from here.\n", 1)

