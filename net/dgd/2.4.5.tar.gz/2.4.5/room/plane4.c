#include "room.h"

TWO_EXIT("room/ruin", "north",
	 "room/plane2", "west",
	 "A large open plain",
	 "A large open plain.\n", 1)
