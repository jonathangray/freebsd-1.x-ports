#include "room.h"

TWO_EXIT("room/forest10", "west",
	 "room/forest4", "north",
	 "Deep forest",
	 "You are in the deep forest.\n", 1)
