#include "room.h"

TWO_EXIT("room/forest9", "east",
	 "room/forest12", "west",
	 "Deep forest",
	 "You are in the deep forest.\n", 1)
