#include "room.h"
TWO_EXIT("room/sunalley2","west",
         "room/eastroad3","east",
"Sun alley",
"Sun alley runs east-west.\n",
1)

