#include "room.h"

TWO_EXIT("room/forest8", "west",
	 "room/forest4", "east",
	 "Deep forest",
	 "You are in the deep forest.\n", 1)
