#include "room.h"
ONE_EXIT("room/vill_shore","north",
"Fields",
"You are in the middle of the fields where the city grows all its crops.\n"+
"A road runs north of here.\n",
1)
