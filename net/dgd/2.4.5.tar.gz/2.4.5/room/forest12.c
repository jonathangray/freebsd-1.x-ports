#include "room.h"

TWO_EXIT("room/south/sforst1", "south",
	 "room/forest11", "east",
	 "Deep forest",
	 "You are in the deep forest.\n", 1)
