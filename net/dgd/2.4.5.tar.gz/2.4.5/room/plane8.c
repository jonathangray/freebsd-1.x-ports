#include "room.h"

THREE_EXIT("room/plane13", "north",
	   "room/plane6", "west",
	   "room/ruin", "south",
	   "A large open plain",
	   "A large open plain.\n", 1)
