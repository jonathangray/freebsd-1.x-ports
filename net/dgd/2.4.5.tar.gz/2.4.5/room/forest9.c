#include "room.h"

THREE_EXIT("room/forest8", "north",
	 "room/forest10", "east",
	 "room/forest11", "west",
	 "Deep forest",
	 "You are in the deep forest.\n", 1)
