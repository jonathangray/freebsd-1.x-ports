#include "room.h"

FOUR_EXIT("room/plane3", "south",
	  "room/plane11", "north",
	  "room/plane8", "east",
	  "room/plane10", "west",
	  "A large open plain",
	  "A large open plain.\n",
	  1)
