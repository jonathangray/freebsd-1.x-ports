#include "room.h"

TWO_EXIT("room/slope", "north",
	 "room/forest4", "south",
	 "Deep forest",
	 "You are in the deep forest.\n", 1)
