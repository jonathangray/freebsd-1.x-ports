#include "../room.h"
ONE_EXIT("room/mine/tunnel17", "east",
	 "Dead end",
	 "In the tunnel into the mines.\n", 0)
