#include "../room.h"
TWO_EXIT("room/mine/tunnel", "south",
	 "room/mine/tunnel3", "north",
	 "Tunnel",
	 "In the tunnel into the mines.\n", 0)
