#include "../room.h"
THREE_EXIT("room/mine/tunnel19", "south",
	 "room/mine/tunnel21", "west",
	 "room/mine/tunnel23", "east",
	 "Tunnel",
	 "Tunnel fork.\n", 0)
