#include "../room.h"
TWO_EXIT("room/mine/tunnel20", "west",
	 "room/mine/tunnel22", "east",
	 "Tunnel",
	 "Tunnel into the mines.\n", 0)
