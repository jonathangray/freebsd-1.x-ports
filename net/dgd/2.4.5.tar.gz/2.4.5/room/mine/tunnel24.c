#include "../room.h"
TWO_EXIT("room/mine/tunnel23", "west",
	 "room/mine/tunnel25", "down",
	 "Tunnel",
	 "The tunnel slopes steeply down a hole here.\n", 0)
