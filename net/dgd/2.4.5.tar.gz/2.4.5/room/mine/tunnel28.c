#include "../room.h"
TWO_EXIT("room/mine/tunnel26", "west",
	 "room/mine/tunnel29", "east",
	 "Tunnel",
	 "Tunnel into the mines.\n", 0)
