#include "../room.h"
THREE_EXIT("room/mine/tunnel19", "north",
	 "room/mine/tunnel16", "south",
	 "room/mine/tunnel18", "west",
	 "Tunnel",
	 "The tunnel into the mines.\n", 0)
