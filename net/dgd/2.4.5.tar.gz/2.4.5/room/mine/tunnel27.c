#include "../room.h"
ONE_EXIT("room/mine/tunnel26", "south",
	 "Dead end",
	 "End of tunnel.\n", 0)
