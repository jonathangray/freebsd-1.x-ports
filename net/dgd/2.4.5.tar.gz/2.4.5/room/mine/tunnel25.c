#include "../room.h"
TWO_EXIT("room/mine/tunnel24", "up",
	 "room/mine/tunnel26", "north",
	 "Tunnel",
	 "The tunnel slopes steeply down a hole here.\n", 0)
