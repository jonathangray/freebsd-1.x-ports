#include "../room.h"
TWO_EXIT("room/mine/tunnel9", "east",
	 "room/mine/tunnel11", "west",
	 "Tunnel",
	 "In the tunnel into the mines.\n", 0)
