#include "../room.h"

TWO_EXIT("room/mine/tunnel3", "up",
	 "room/mine/tunnel9", "down",
	 "Shaft",
	 "In a shaft going straight down.\n", 0)
