#include "../room.h"
TWO_EXIT("room/mine/tunnel22", "west",
	 "room/mine/tunnel24", "east",
	 "Tunnel",
	 "Tunnel into the mines.\n", 0)
