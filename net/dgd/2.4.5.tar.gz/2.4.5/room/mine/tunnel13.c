#include "../room.h"
ONE_EXIT("room/mine/tunnel12", "south",
	 "Tunnel",
	 "End of the tunnel.\n", 0)
