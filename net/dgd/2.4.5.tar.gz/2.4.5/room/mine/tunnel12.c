#include "../room.h"
TWO_EXIT("room/mine/tunnel11", "south",
	 "room/mine/tunnel13", "north",
	 "Tunnel",
	 "In the tunnel into the mines.\n", 0)
