#include "../room.h"
TWO_EXIT("room/mine/tunnel16", "east",
	 "room/mine/tunnel14", "west",
	 "Tunnel",
	 "In the tunnel into the mines.\n", 0)
