#include "../room.h"
TWO_EXIT("room/mine/tunnel17", "south",
	 "room/mine/tunnel22", "north",
	 "Tunnel",
	 "The tunnel splits up in a fork forward.\n", 0)
