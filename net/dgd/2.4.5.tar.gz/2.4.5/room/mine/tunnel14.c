#include "../room.h"
TWO_EXIT("room/mine/tunnel15", "east",
	 "room/mine/tunnel9", "west",
	 "Tunnel",
	 "In the tunnel into the mines.\n", 0)
