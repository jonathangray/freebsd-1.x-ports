#include "../room.h"
TWO_EXIT("room/mine/tunnel10", "east",
	 "room/mine/tunnel12", "north",
	 "Tunnel",
	 "In the tunnel into the mines.\n", 0)
