#include "../room.h"
THREE_EXIT("room/mine/tunnel25", "south",
	 "room/mine/tunnel27", "north",
	 "room/mine/tunnel28", "east",
	 "Tunnel",
	 "The tunnel slopes steeply down a hole here.\n", 0)
