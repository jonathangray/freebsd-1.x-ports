#include "../room.h"
ONE_EXIT("room/mine/tunnel21", "east",
	 "Dead end",
	 "Dead end.\n", 0)
