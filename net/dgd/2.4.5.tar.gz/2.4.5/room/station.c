#include "room.h"

ONE_EXIT("room/vill_road2", "up",
	 "Central point",
"This is the central point. A lot of traffic seems to have passed through\n"+
"here. If you just wait long enough, some transport might pick you up.\n", 1)
