#include "room.h"

FOUR_EXIT("room/plane6", "south",
	  "room/mount_pass", "north",
	  "room/plane13", "east",
	  "room/plane12", "west",
	  "A large open plain",
	  "A large open plain, There is a mountain to the north.\n", 1)
