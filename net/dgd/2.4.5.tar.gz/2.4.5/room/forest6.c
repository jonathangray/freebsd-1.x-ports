#include "room.h"

ONE_EXIT("room/forest4", "west",
	 "Deep forest",
	 "You are in the deep forest.\n", 1)
