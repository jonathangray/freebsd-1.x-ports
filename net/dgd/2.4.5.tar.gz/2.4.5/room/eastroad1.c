#include "room.h"
TWO_EXIT("room/eastroad2","north",
         "room/vill_shore","south",
"East road",
"East road runs north-south.\n",
1)

