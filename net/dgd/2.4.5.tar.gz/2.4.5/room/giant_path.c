#include "room.h"

TWO_EXIT("room/big_tree", "east",
	 "room/giant_lair", "west",
	 "A path",
	 "You are on a path going in east/west direction. There are some\n" +
	 "VERY big footsteps here.\n", 1)

