#include "room.h"

TWO_EXIT("room/ravine", "down",
	 "room/mount_top2", "east",
	 "Top of mountain",
	 "You are on top of a mountain. There is a small plateau to the\n"+
	 "east.\n", 1)
