#include "room.h"
TWO_EXIT("room/eastroad3","north",
         "room/eastroad1","south",
"East road",
"East road runs north-south.\n",
1)

