#include "room.h"

FOUR_EXIT("room/plane2", "south",
	  "room/plane6", "north",
	  "room/ruin", "east",
	  "room/plane7", "west",
	  "A large open plain",
	  "A large open plain. There are some kind of building to the east.\n",
	  1)
