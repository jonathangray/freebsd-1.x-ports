#include "room.h"

FOUR_EXIT("room/forest3", "north",
	 "room/forest5", "west",
	 "room/forest6", "east",
	 "room/forest7", "south",
	 "Deep forest",
	 "You are in the deep forest.\n", 1)
