#include "room.h"

FOUR_EXIT("room/plane5", "south",
	  "room/plane10", "north",
	  "room/plane3", "east",
	  "room/big_tree", "west",
	  "A large open plain",
	  "A large open plain. There is a big tree to the west.\n",
	  1)
