#include "room.h"

ONE_EXIT("room/plane12", "east",
	 "Deep forest",
	 "In the deep forest. The wood lights up to the east.\n", 1)
