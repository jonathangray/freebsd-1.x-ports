#include "room.h"

THREE_EXIT("room/orc_vall", "west",
	 "room/forest2", "east",
	 "room/forest3", "south",
	 "A slope",
	 "The forest gets light here, and slopes down to the west.\n", 1)
