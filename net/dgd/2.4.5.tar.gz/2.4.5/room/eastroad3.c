#include "room.h"
THREE_EXIT("room/eastroad4","north",
         "room/eastroad2","south",
         "room/sunalley1","west",
"East road",
"East road runs north-south.\n"+
"Sun alley is to the west.\n",
1)

