#include "room.h"

FOUR_EXIT("room/plane1", "south",
	  "room/plane3", "north",
	  "room/plane4", "east",
	  "room/plane5", "west",
	  "A large open plain",
	  "A large open plain, extending in all directions.\n", 1)
