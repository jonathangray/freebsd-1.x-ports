#include "room.h"

TWO_EXIT("room/plane7", "north",
	 "room/plane2", "east",
	 "A large open plain",
	 "A large open plain.\n", 1)
