#include "room.h"
TWO_EXIT("room/eastroad4","south",
"room/inn","west",
"East road",
"East road runs south from here.\n"+
"To the west lies the Eastroad Inn.\n",
1)
