#include "room.h"

THREE_EXIT("room/forest1", "east",
	   "room/forest2", "west",
	   "room/plane1", "north",
	   "Clearing",
	   "A small clearing. There are trees all around you.\n" +
	   "However, the trees are sparse to the north.\n", 1)
