#include "room.h"

TWO_EXIT("room/plane11", "west",
	   "room/plane8", "south",
	   "A large open plain",
	   "A large open plain. There is a mountain to the north,\nbut it is to steep to climb.\n", 1)
