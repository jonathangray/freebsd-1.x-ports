#include "room.h"
TWO_EXIT("room/eastroad5","north",
         "room/eastroad3","south",
"East road",
"East road runs north-south.\n",
1)

