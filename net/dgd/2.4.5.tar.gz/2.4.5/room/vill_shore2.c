#include "room.h"
TWO_EXIT("room/jetty","west",
	 "room/jetty2","east",
	 "Village shore",
"The village shore. A jetty leads out to the east. To the north some stairs\n"+
"leads down to the north beach. A road starts to the west\n", 1)
