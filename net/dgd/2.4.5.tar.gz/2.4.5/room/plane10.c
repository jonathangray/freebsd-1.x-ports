#include "room.h"

THREE_EXIT("room/plane12", "north",
	   "room/plane6", "east",
	   "room/plane7", "south",
	   "A large open plain",
	   "A large open plain.\n", 1)
