#include "room.h"

THREE_EXIT("room/deep_forest1", "west",
	   "room/plane11", "east",
	   "room/plane10", "south",
	   "A large open plain",
	   "A large open plain. There is a forest to the west\n", 1)
